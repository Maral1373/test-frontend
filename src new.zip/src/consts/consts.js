export const API = "https://test-backend-b9qq.onrender.com/api";
export const SITE_NAME = "Maral's mobile shop";